plugins { id("com.android.application") }

android { namespace = "com.magicsum.app"; compileSdk = 36
    defaultConfig { applicationId = "com.magicsum.app"; minSdk = 23; targetSdk = 36; versionCode = 1; versionName = "1.0" }
}
